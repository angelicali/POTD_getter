1. put your netid and password in info.txt, seperated by space
2. run POTD_getter.exe
